package User;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class admin {
	public String sqladmname = new String();
    public static String sqladmid = new String();
    public static String sqladmpw = new String();
    public static String sqladmstate = new String();
    public static String sqladmroles = new String();
    public static String sqladmachievements = new String();


	private static Connection conn = null;
	static Connection getConnection(){
		if (conn != null) {
			return conn;
		}
		String driver_MySQL = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3307/欢乐斗地主";
		String account_MySQL = "root";
		String password_MySQL = "";

		try {
			Class.forName(driver_MySQL);
			conn = DriverManager.getConnection(url, account_MySQL,password_MySQL);
			System.out.println("连接数据库成功");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("创建数据库连接失败！");
		}
		return conn;
	    }
	public static void admzhuce(String name,String id,String pw,String state, String roles,String achievements) {
		String s1 = name;
		String s2 = id;
		String s3 = pw;
		String s4 = state;
		String s5 = roles;
		String s6 = achievements;
		String sqlstuzhue = "insert into adm (admname,admid,admpw,adimstate,adimroles,adimachievements) value (?,?,?,?,?,?)";
		try {
			PreparedStatement ps = getConnection().prepareStatement(sqlstuzhue);
			ps.setString(1, s1);
			ps.setString(2, s2);
			ps.setString(3, s3);
			ps.setString(4, s4);
			ps.setString(5, s5);
			ps.setString(6, s6);
			ps.executeUpdate();
			System.out.println("写入成功");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void admQquery(String u){
		String sql = "select * from adm where admid = " + "'"+u+"'";
		try {
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if (rs.next() == true) {
				sqladmid=rs.getString("admid");
				sqladmpw=rs.getString("admpw");
				sqladmstate=rs.getString("state");
				sqladmroles=rs.getString("roles");
				sqladmachievements=rs.getString("achievements");
				
			}
		} catch (SQLException e) {
			System.out.println("查询数据出现异常: " + e.getMessage());
		}
	}
	
public static void main(String[] args) {
	// TODO Auto-generated method stub

}

}

}
