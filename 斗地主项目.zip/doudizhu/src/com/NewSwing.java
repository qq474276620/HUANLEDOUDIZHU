package com;

import javax.swing.SwingUtilities;

public class NewSwing {
	
}