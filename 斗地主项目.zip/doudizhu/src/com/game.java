package com;

public class game {
	class account{
		public String name;
		public int pw;
		public String avatar;
		public int level;
		public String status;
		public String profile;
		public String honor;
		public String record;
		public String character;
		public String costume;
	}
	class joybeans{
		public int denomination;
	}
	class diamond{
		public int denomination;
	}
	class card{
		public int denomination;
	}
	class leaderboard{
		public String username;
		public int rank;
		public int level;
		public String avatar;
		public String title;
		public String segment;
		public int win;
	}
	class friends{
		public String username;
		public String avatar;
		public String status;
		public int level;
		public String segment;
	}
	class task{
		public String novice;
		public String team;
		public String dally;
		public String weekly;
		public String challenge;
	}
	class settings{
		public String transformation;
		public String titledisplay;
		public String worldchat;
		public String BGM;
		public String soundeffects;
		public String sceneswitching;
		public String aocountchange;
	}
	class email{
		public String username;
		public String avatar;
		public String rewardcontent;
	}
	class back{
		public String experienceitems;
		public String raffletickets;
		public String experiencecards;
		public String props;
		public String tickets;
		public String scenes;
	}
	class mall{
		public int joybeans ;
		public int diamond;
		public String dressup;
		public String prors;
		public String characters;
		public String treasurehunt;
		public String scene;
	}
	class worldchat{
		public String username;
		public String avatar;
	}
	class friendchat{
		public String username;
		public String avatar;
		public String status;
	}
	class groupchat{
		public String username;
		public String avatar;
	}
	


}
