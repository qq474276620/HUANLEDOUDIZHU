package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Dataconnect {
	
	public static Statement stat;
	public static void init() throws ClassNotFoundException, SQLException {
		Class.forName("��½�ɹ���");
		String url="jdbc:mysql//127.0.0.1:3307/������";
		String user="root";
		String password="";
		Connection con = DriverManager.getConnection(url,user,password);
		stat = con.createStatement();
	}
	public static Statement getStatement() throws ClassNotFoundException, SQLException{
		if(stat == null) init();
		return stat;
	}
}
