package com;

import java.sql.ResultSet;
import java.sql.SQLException;


public class User {
	private boolean islogin;
	public User(){
		islogin = false;
	}
	
	int id;
	String pw;
	
	public User(int id, String pw) {
		super();
		this.id = id;
		this.pw = pw;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	
	public User login(int id,String pw) throws SQLException, ClassNotFoundException{
		User u = null;
		if(!islogin){
			String sql = "select * from user where id ="+id+" and pw='"+pw+"'";
			ResultSet rs = Dataconnect.getStatement().executeQuery(sql);
			if(rs.next()){
				int type = rs.getInt("type");
				if(type ==0){
					u = new User(rs.getInt(1),rs.getString(2));
				}
			}
		}
		return u;
	}
}
